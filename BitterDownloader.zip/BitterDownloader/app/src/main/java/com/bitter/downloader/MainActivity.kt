package com.bitter.downloader

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import java.net.URLConnection

data class DownloadItem(val id: Long, val name: String, val url: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BitterDownloaderApp() }
    }
}

@Composable
fun BitterDownloaderApp() {
    val context = LocalContext.current
    var url by remember { mutableStateOf("") }
    var downloads by remember { mutableStateOf(listOf<DownloadItem>()) }
    var message by remember { mutableStateOf("") }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Bitter Downloader") }) }
        ) { padding ->
            Column(
                modifier = Modifier
                    .padding(padding)
                    .padding(16.dp)
                    .fillMaxSize()
            ) {
                Text("Baixar vídeo ou música", style = MaterialTheme.typography.headlineSmall)
                Spacer(Modifier.height(12.dp))

                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Cole o link do arquivo") },
                    placeholder = { Text("https://exemplo.com/video.mp4") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                    singleLine = true
                )

                Spacer(Modifier.height(12.dp))

                Button(
                    onClick = {
                        val cleanUrl = url.trim()
                        if (!cleanUrl.startsWith("http://") && !cleanUrl.startsWith("https://")) {
                            message = "Cole um link HTTP ou HTTPS válido."
                            return@Button
                        }
                        try {
                            val uri = Uri.parse(cleanUrl)
                            val guessed = URLConnection.guessContentTypeFromName(uri.lastPathSegment ?: "")
                            val ext = when {
                                guessed?.contains("audio") == true -> ".mp3"
                                guessed?.contains("video") == true -> ".mp4"
                                uri.lastPathSegment?.contains(".") == true ->
                                    "." + uri.lastPathSegment!!.substringAfterLast(".").take(5)
                                else -> ".download"
                            }
                            val base = uri.lastPathSegment?.substringBeforeLast(".")
                                ?.ifBlank { "bitter_download" } ?: "bitter_download"

                            val request = DownloadManager.Request(uri)
                                .setTitle(base + ext)
                                .setDescription("Bitter Downloader")
                                .setNotificationVisibility(
                                    DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
                                )
                                .setDestinationInExternalPublicDir(
                                    Environment.DIRECTORY_DOWNLOADS,
                                    "BitterDownloader/$base$ext"
                                )
                                .setAllowedOverMetered(true)
                                .setAllowedOverRoaming(false)

                            val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                            val id = manager.enqueue(request)
                            downloads = downloads + DownloadItem(id, base + ext, cleanUrl)
                            message = "Download iniciado."
                            url = ""
                        } catch (e: Exception) {
                            message = "Não foi possível iniciar o download."
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("⬇️  BAIXAR")
                }

                if (message.isNotBlank()) {
                    Spacer(Modifier.height(10.dp))
                    Text(message)
                }

                Spacer(Modifier.height(20.dp))
                Text("Downloads desta sessão", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))

                if (downloads.isEmpty()) {
                    Text("Nenhum download iniciado ainda.")
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(downloads) { item ->
                            Card(Modifier.fillMaxWidth()) {
                                Row(
                                    Modifier.padding(12.dp).fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(Modifier.weight(1f)) {
                                        Text(item.name)
                                        Text(
                                            item.url,
                                            style = MaterialTheme.typography.bodySmall,
                                            maxLines = 1
                                        )
                                    }
                                    Text("⬇️")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
