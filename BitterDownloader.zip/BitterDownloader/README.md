# Bitter Downloader

Aplicativo Android para baixar arquivos de vídeo e áudio a partir de URLs HTTP/HTTPS que permitam download direto.

## Como abrir
1. Extraia o ZIP.
2. Abra a pasta no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Conecte um telefone Android ou use um emulador.
5. Execute o app.

## Uso
Cole uma URL direta para um arquivo permitido (por exemplo, um .mp4, .mp3 ou outro arquivo que o servidor disponibilize para download) e toque em **BAIXAR**.

Os arquivos são salvos em:
`Downloads/BitterDownloader/`

## Observação
O projeto não tenta contornar DRM, autenticação, paywalls ou restrições de plataformas. O download depende de a URL disponibilizar o arquivo diretamente.
